#/bin/sh
#correr programa con permisos de super usuario
sudo apt-get install python-pygraph python-pygraphviz python-scapy
sudo apt-get install python-numpy python-scipy python-matplotlib
sudo apt-get install python-mpltoolkits.basemap
sudo apt-get install traceroute whois