### Demo: basic

Estos scripts muestran un ejemplo básico de uso de sockets PTC. En `server.py`, se declara un socket y se lo lleva al estado `LISTEN` luego de ligarlo a una dirección local. En `client.py`, otro socket se conecta activamente a esta dirección y luego se intercambian dos mensajes breves bidireccionalmente.
