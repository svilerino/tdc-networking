### Demo: file_transfer

Estos scripts muestran un ejemplo de uso de sockets PTC un poco más interesante. Dos instancias de PTC, luego de establecer una conexión, intercambiarán imágenes entre sí. Los bytes recibidos de la red se terminan guardando en un archivo con prefijo `recvd_`. 
